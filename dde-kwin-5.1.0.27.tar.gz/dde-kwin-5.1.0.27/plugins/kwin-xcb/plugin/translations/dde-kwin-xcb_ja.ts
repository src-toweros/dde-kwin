<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja" version="2.1">
<context>
    <name>WindowMenu</name>
    <message>
        <location filename="../libkwinpreload.cpp" line="111"/>
        <source>Minimize</source>
        <translation>最小化</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="114"/>
        <source>Unmaximize</source>
        <translation>元のサイズに戻す</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="115"/>
        <source>Maximize</source>
        <translation>最大化</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="117"/>
        <source>Move</source>
        <translation>移動</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="119"/>
        <source>Resize</source>
        <translation>サイズ変更</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="121"/>
        <source>Always on Top</source>
        <translation>常に最前面に表示</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="123"/>
        <source>Always on Visible Workspace</source>
        <translation>表示中のワークスペースに常に表示</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="125"/>
        <source>Move to Workspace Left</source>
        <translation>左のワークスペースに移動</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="127"/>
        <source>Move to Workspace Right</source>
        <translation>右のワークスペースに移動</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="129"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
</context>
</TS>