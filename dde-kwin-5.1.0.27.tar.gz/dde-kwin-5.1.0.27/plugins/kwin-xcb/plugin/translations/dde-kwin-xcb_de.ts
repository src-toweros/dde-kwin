<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.1">
<context>
    <name>WindowMenu</name>
    <message>
        <location filename="../libkwinpreload.cpp" line="111"/>
        <source>Minimize</source>
        <translation>Minimieren</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="114"/>
        <source>Unmaximize</source>
        <translation>Unmaximieren</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="115"/>
        <source>Maximize</source>
        <translation>Maximieren</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="117"/>
        <source>Move</source>
        <translation>Bewegen</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="119"/>
        <source>Resize</source>
        <translation>Größe ändern</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="121"/>
        <source>Always on Top</source>
        <translation>Immer im Vordergrund</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="123"/>
        <source>Always on Visible Workspace</source>
        <translation>Immer auf sichtbarem Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="125"/>
        <source>Move to Workspace Left</source>
        <translation>Nach links in den Arbeitsbereich verschieben</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="127"/>
        <source>Move to Workspace Right</source>
        <translation>Nach rechts in den Arbeitsbereich verschieben</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="129"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
</TS>