<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
<context>
    <name>WindowMenu</name>
    <message>
        <location filename="../libkwinpreload.cpp" line="111"/>
        <source>Minimize</source>
        <translation>최소화</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="114"/>
        <source>Unmaximize</source>
        <translation>최대화 해제</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="115"/>
        <source>Maximize</source>
        <translation>최대화</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="117"/>
        <source>Move</source>
        <translation>이동</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="119"/>
        <source>Resize</source>
        <translation>크기 조정</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="121"/>
        <source>Always on Top</source>
        <translation>항상 위에</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="123"/>
        <source>Always on Visible Workspace</source>
        <translation>항상 보여는 작업 공간</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="125"/>
        <source>Move to Workspace Left</source>
        <translation>작업 공간 왼쪽으로 이동</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="127"/>
        <source>Move to Workspace Right</source>
        <translation>작업 공간 오른쪽으로 이동</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="129"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
</context>
</TS>