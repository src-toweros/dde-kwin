<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>WindowMenu</name>
    <message>
        <location filename="../libkwinpreload.cpp" line="111"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="114"/>
        <source>Unmaximize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="115"/>
        <source>Maximize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="117"/>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="119"/>
        <source>Resize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="121"/>
        <source>Always on Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="123"/>
        <source>Always on Visible Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="125"/>
        <source>Move to Workspace Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="127"/>
        <source>Move to Workspace Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="129"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
