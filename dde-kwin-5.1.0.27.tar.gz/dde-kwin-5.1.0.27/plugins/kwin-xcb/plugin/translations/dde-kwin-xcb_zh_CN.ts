<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
<context>
    <name>WindowMenu</name>
    <message>
        <location filename="../libkwinpreload.cpp" line="111"/>
        <source>Minimize</source>
        <translation>最小化</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="114"/>
        <source>Unmaximize</source>
        <translation>还原</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="115"/>
        <source>Maximize</source>
        <translation>最大化</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="117"/>
        <source>Move</source>
        <translation>移动</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="119"/>
        <source>Resize</source>
        <translation>更改大小</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="121"/>
        <source>Always on Top</source>
        <translation>总在最前</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="123"/>
        <source>Always on Visible Workspace</source>
        <translation>总在可见工作区</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="125"/>
        <source>Move to Workspace Left</source>
        <translation>移至左边的工作区</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="127"/>
        <source>Move to Workspace Right</source>
        <translation>移至右边的工作区</translation>
    </message>
    <message>
        <location filename="../libkwinpreload.cpp" line="129"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
</TS>