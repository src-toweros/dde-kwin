<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>thumbmanager</name>
    <message>
        <source>Drag upwards to remove</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
